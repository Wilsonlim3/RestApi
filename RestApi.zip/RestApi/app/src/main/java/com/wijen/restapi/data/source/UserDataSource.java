package com.wijen.restapi.data.source;

import io.reactivex.Observable;

public interface UserDataSource {

    Observable<String> getApi(String name);

}
