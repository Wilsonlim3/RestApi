package com.wijen.restapi.data.source.factory;

import com.wijen.restapi.data.RestApi;
import com.wijen.restapi.data.network.retrofit.RetrofitRestApiImpl;
import com.wijen.restapi.data.source.UserDataSource;
import com.wijen.restapi.data.source.cloud.CloudUserDataSource;

public class UserDataSourceFactory {
    public UserDataSource createUserDataSource(){
        RestApi restApi =new RetrofitRestApiImpl();
        return new CloudUserDataSource(restApi);
    }

    //local when needed
//    public AccountDataSource createLocalDataSource() {
//        LocalApi localApi = new RealmDataSource();
//        ContentResolverDataSource contentResolverDataSource = new ContentResolverDataSource();
//        return new LocalAccountDataSource(localApi, contentResolverDataSource);
//    }
}
