package com.wijen.restapi.data.source.local;

import com.wijen.restapi.data.source.UserDataSource;

import io.reactivex.Observable;

public class LocalUserDataSource implements UserDataSource {
    @Override
    public Observable<String> getApi(String name) {
        return null;
    }
}
