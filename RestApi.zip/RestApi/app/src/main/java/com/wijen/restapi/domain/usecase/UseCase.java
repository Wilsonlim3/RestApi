package com.wijen.restapi.domain.usecase;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.schedulers.Schedulers;

public abstract class UseCase<T> {

    private final CompositeDisposable compositeDisposable = new CompositeDisposable();

    /**
     * Executes the current use case.
     *
     * @param useCaseSubscriber The guy who will be listen to the observable build
     *                          with {@link #buildUseCaseObservable()}.
     */
    public DisposableObserver execute(DisposableObserver useCaseSubscriber) {
        DisposableObserver disposableObserver = buildUseCaseObservable()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(useCaseSubscriber);
        compositeDisposable.add(disposableObserver);
        return disposableObserver;
    }

    protected abstract Observable<T> buildUseCaseObservable();

    /**
     * Unsubscribes from current {rx.Subscription}.
     */
    public void unsubscribe() {
        if (!compositeDisposable.isDisposed()) {
            compositeDisposable.dispose();
            compositeDisposable.clear();
        }

    }
}
