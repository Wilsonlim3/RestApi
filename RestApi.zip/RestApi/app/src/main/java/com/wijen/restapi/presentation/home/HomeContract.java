package com.wijen.restapi.presentation.home;

public interface HomeContract {
    interface View{
        void successHitApi();
    }

    interface Presenter{
        void hitApi(String name);
    }
}
