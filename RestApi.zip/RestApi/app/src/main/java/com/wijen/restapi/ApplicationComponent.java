package com.wijen.restapi;

import com.wijen.restapi.data.source.factory.UserDataSourceFactory;
import com.wijen.restapi.domain.repository.UserDataRepository;
import com.wijen.restapi.domain.repository.UserRepository;
import com.wijen.restapi.domain.usecase.HitApiUseCase;

public class ApplicationComponent {
    private ApplicationComponent() {
    }

    private static UserRepository provideUserRepository() {
        UserDataSourceFactory userDataSourceFactory =
                new UserDataSourceFactory();
        return new UserDataRepository(userDataSourceFactory.createUserDataSource());
    }


    public static HitApiUseCase provideHitApiUseCase(){
        return new HitApiUseCase(provideUserRepository());
    }
}
