package com.wijen.restapi.presentation.home;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.wijen.restapi.domain.usecase.HitApiUseCase;

import io.reactivex.observers.DisposableObserver;

public class HomeViewModel extends ViewModel {

    HitApiUseCase hitApiUseCase;
    private MutableLiveData<String> mText;

    public HomeViewModel(HitApiUseCase hitApiUseCase) {
        mText = new MutableLiveData<>();
        mText.setValue("This is home fragment");

        this.hitApiUseCase = hitApiUseCase;
    }

    public LiveData<String> getText() {
        return mText;
    }

    public void hitApi(){
        hitApiUseCase.execute(new DisposableObserver<String>() {
            @Override
            public void onNext(String string) {
                Log.d("WJN","ONNEXT");
            }

            @Override
            public void onError(Throwable e) {
                Log.d("WJN","ONERROR : " + e.getLocalizedMessage());
            }

            @Override
            public void onComplete() {

            }
        });
    }
}