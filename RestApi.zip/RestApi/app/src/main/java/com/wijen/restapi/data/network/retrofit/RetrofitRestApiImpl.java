package com.wijen.restapi.data.network.retrofit;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import com.wijen.restapi.data.RestApi;

import io.reactivex.Observable;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitRestApiImpl implements RestApi {

    public RetrofitRestApiImpl() {
        buildRetrofit();
    }

    private RetrofitRestApi apiService;

    private void buildRetrofit() {
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();

        Retrofit retrofit = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create(gson))
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .baseUrl("soontobeurl.com")
                .client(createHttpClient(true))
                .build();
        apiService = retrofit.create(RetrofitRestApi.class);
    }
    private OkHttpClient createHttpClient(boolean cacheable) {
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
//        httpClient.addInterceptor(new RequestInterceptor(reqId));
//        httpClient.addInterceptor(new ResponseInterceptor());
//        httpClient.addInterceptor(new ChuckInterceptor(BcaApplication.getAppContext()));
//        if (cacheable) {
//            setCache(httpClient);
//        }
//        setTimeout(httpClient);
//        setLogger(httpClient);
//        enableTls12OnPreLollipop(httpClient);
        return httpClient.build();
    }

    @Override
    public Observable<String> hitApi(String url, String name) {
        return apiService.hitApi(url, name);
    }
}
