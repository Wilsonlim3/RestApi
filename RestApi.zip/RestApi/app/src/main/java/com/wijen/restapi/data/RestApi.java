package com.wijen.restapi.data;

import io.reactivex.Observable;

public interface RestApi {
    Observable<String>hitApi(String url, String name);
}
