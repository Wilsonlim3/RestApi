package com.wijen.restapi.data.network.retrofit;

import io.reactivex.Observable;
import retrofit2.http.GET;
import retrofit2.http.Query;
import retrofit2.http.Url;

public interface RetrofitRestApi {

    @GET
    Observable<String> hitApi(@Url String url, @Query("name")String name);

}
