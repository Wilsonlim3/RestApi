package com.wijen.restapi.domain.usecase;

import com.wijen.restapi.domain.repository.UserRepository;

import io.reactivex.Observable;

public class HitApiUseCase extends UseCase {

    private String name = "testName";
    private UserRepository userRepository;

    public HitApiUseCase(UserRepository userRepository) {
        this.userRepository = userRepository;
    }



    @Override
    protected Observable buildUseCaseObservable() {
        return userRepository.getApi(name);
    }
}
