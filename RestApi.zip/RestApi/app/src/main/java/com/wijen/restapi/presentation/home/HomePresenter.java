package com.wijen.restapi.presentation.home;

import android.util.Log;

import com.wijen.restapi.domain.usecase.HitApiUseCase;

import io.reactivex.observers.DisposableObserver;

public class HomePresenter implements HomeContract.Presenter{

    private final HomeContract.View view;
    private final HitApiUseCase hitApiUseCase;

    public HomePresenter(HomeContract.View view, HitApiUseCase hitApiUseCase) {
        this.view = view;
        this.hitApiUseCase = hitApiUseCase;
    }

    public void hitApi(String name){
        hitApiUseCase.execute(new DisposableObserver<String>() {
            @Override
            public void onNext(String string) {
                Log.d("WJN","ONNEXT");
            }

            @Override
            public void onError(Throwable e) {
                Log.d("WJN","ONERROR : " + e.getLocalizedMessage());
            }

            @Override
            public void onComplete() {

            }
        });
    }
}
