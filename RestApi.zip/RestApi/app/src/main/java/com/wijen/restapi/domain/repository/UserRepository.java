package com.wijen.restapi.domain.repository;


import io.reactivex.Observable;

public interface UserRepository {

    Observable<String> getApi(String name);
}
