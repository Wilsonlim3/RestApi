package com.wijen.restapi.data.source.cloud;

import com.wijen.restapi.data.RestApi;
import com.wijen.restapi.data.source.UserDataSource;

import io.reactivex.Observable;

public class CloudUserDataSource implements UserDataSource {

    private final RestApi restApi;

    public CloudUserDataSource(RestApi restApi) {
        this.restApi = restApi;
    }

    @Override
    public Observable<String> getApi(String name) {
        String url = "/greetings";
        return restApi.hitApi(url, name);
    }
}
