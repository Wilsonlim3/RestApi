package com.wijen.restapi.domain.repository;

import com.wijen.restapi.data.source.UserDataSource;

import io.reactivex.Observable;

public class UserDataRepository implements UserRepository {

    private UserDataSource userDataSourceCloud;

    public UserDataRepository(UserDataSource userDataSourceCloud) {
        this.userDataSourceCloud = userDataSourceCloud;
    }

    @Override
    public Observable<String> getApi(String name) {
        return userDataSourceCloud.getApi(name);
    }
}
